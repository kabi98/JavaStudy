package question04;

public class Zelda extends Game {
	void start() {
		System.out.println("그래픽이 황홀한 zelda 시작!");
	}

}
