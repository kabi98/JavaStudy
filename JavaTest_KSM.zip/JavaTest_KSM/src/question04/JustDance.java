package question04;

public class JustDance extends Game {
	void start() {
		System.out.println("신나는 댄스게임 시작!");
	}

}
