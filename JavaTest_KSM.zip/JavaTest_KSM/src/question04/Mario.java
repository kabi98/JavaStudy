package question04;

public class Mario extends Game{
	void start() {
		System.out.println("귀여운 Mario 게임 시작!");
	}

}
