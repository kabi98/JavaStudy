package question04;

public class Game {
	void start() {
		System.out.println("게임시작");
	}

}
