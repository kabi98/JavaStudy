/**
 * 
 */
/**
 * @author smhrd
 *
 */
module JavaTest_KSM {
}