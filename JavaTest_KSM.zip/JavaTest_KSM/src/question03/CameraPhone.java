package question03;

public class CameraPhone extends MobilePhone{

	void picture() {
		System.out.println("사진찍기");
	}
	
	void music() {
		System.out.println("노래듣기");
	}
}
