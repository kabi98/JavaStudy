package question03;

public class SmartPhone extends CameraPhone{

	void kakaoTalk() {
		System.out.println("카톡보내기");
	}
	
	void wifi() {
		System.out.println("무료 인터넷접속하기");
	}
	
}
