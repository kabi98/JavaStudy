package question03;

public class MobilePhone {
	public String phoneNumber;
	
	public void call() {
		System.out.println("전화걸기");
	}
	public void message() {
		System.out.println("문자보내기");
	}

}
