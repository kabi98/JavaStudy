# Console Card Game [ARCHIVED (REASON: OLD CODE)]
A round based card game played through the console-line interface. 

### Features:
* Multiple modes: Human VS Human / Human VS Computer / Computer VS Computer.
* 3 preset deck factions (Pirates, Elves and Kingdom).
* Modular approach for addition of new decks.
* Editable background music setting.
* Time based attributes and abilities.
* Graveyard system.

### Preview:
![alpha](https://i.gyazo.com/c272c5a3d0d46a804fa54ec258f02337.png)
