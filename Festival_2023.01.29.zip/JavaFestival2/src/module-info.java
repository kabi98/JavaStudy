/**
 * 
 */
/**
 * @author smhrd
 *
 */
module JavaFestival2 {
}