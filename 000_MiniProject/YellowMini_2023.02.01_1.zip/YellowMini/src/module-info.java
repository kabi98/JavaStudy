/**
 * 
 */
/**
 * @author smhrd
 *
 */
module YellowMini {
	requires java.sql;
	requires jfreechart;
	requires java.desktop;
	requires jcommon;
}