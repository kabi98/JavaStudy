/**
 * 
 */
/**
 * @author smhrd
 *
 */
module JavaFestival {
}