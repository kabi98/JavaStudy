## DNS Record

This script takes the website name as input and returns its dns records.

#Requirements to run this file:

External library called dnspython has been used here and it can be installed easily by using the following command:

pip install -r requirements.txt

#How to use this script?

1.Install the requirements.

2. Type the following command

python dns_record.py

3.It will ask for a website:

You can give any website name for example: google.com
