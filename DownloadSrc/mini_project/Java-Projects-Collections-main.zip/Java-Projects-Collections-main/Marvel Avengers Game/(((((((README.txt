STEPS TO RUN THE GAME :
1.Open Command Prompt from the directory *\(((((Mini Project\GUI Based>    //here *=any directories of a drive after unzipping the file
2.Type javac *.java and press enter
3.If you want to play Game with music : Type java PlayGameWithMusic
  else if want to play Game without music : Type java PlayGame
4.The Game Will be Running
Terms
//above game is compiled in JDK16
//run the game with java JDK16