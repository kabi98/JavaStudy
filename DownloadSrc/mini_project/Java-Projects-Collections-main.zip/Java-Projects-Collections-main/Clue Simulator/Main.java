// package edu.miracosta.cs113;
import java.util.Random;

import java.util.Scanner;

public class Main
{
     /**
     * Driver method for random guessing approach
     *
     * @param args not used for driver
     */
    public static void main(String[] args) {
      DetectiveJill.main();

    }
}
