package org.pk.resume.builder.session;

public class ParticipationSessionConstant 
{
	public static String PARTICIPATION = "parti";
	public static String START_DATE = "start_date";
	public static String END_DATE = "end_date";
	public static String SPONSOR = "sponsor";
	public static String NOTE = "note";
	public static String TOPIC = "topic";
	public static String PLACE = "place";
}
