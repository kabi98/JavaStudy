package org.pk.resume.builder.dao;


public class Main {

	public static void main(String[] args) {
		
		/*Personal p = new Personal();
		p.setName("name");
		p.setFatherName("father_name");
		p.setDob("1991-02-12");
		p.setAge("23");
		p.setAddress("jalgaon");
		p.setEmailId("prvnp@gmail.com");
		p.setGender("MALE");
		p.setLangaugeProf("Marathi, English, Hindi");
		p.setMaritalStatus("Single");
		p.setMobileNo("1234567890");
		
		if(us.insertPersonalDetails(p))
		{
			System.out.println("Personal Inserted");
		}
		else
		{
			System.out.println("Personal Error");
		}
		Experience exp = new Experience();
		
		exp.setCourse("10");
		exp.setDesignation("junior developer");
		exp.setEmployer("fsdfdf");
		exp.setExperience("gg");
		exp.setJoiningDate("2015-02-1");
		exp.setLeavingDate("2015-04-1");
		exp.setSubjectThaught("dfsdfsdfd");
		exp.setWorking("fgfghfg");
		
		if(us.insertExperienceDetails(exp))
		{
			System.out.println("Education dfasfds");
		}
		else
		{
			System.out.println("Education Error");
		}
		
		Journal j = new Journal();
		j.setAuthor("fffffff");
		j.setDoiNo("123");
		j.setImpactFactor("sdfsdfsffffff");
		j.setLink("www.ggf");
		j.setName("vdfgs");
		j.setPageNo("111");
		j.setPaperTitle("title");
		j.setPlace("aaaa");
		j.setPublicationDate("2014-01-01");
		j.setPublicationType("vggggggggg");
		j.setVolume("vvvv");
		
		
		if(us.insertJournalDetails(j)){
			System.out.println("journal insert");
		}else{
			System.out.println("journal errror");
		}
		
		Conference j = new Conference();
		j.setAuthor("fffffff");
		j.setDoiNo("123");
		j.setImpactFactor("sdfsdfsffffff");
		j.setLink("www.ggf");
		j.setName("vdfgs");
		j.setPageNo("111");
		j.setPaperTitle("title");
		j.setPlace("aaaa");
		j.setPublicationDate("2014-01-01");
		j.setPublicationType("vggggggggg");
		j.setVolume("vvvv");
		
		
		if(us.insertConferenceDetails(j)){
			System.out.println("journal insert");
		}else{
			System.out.println("journal errror");
		}
		
		
		References ref = new References();
		ref.setAffiliation("vvvvvvvv");
		ref.setContactNo("123454667890");
		ref.setDesignation("junior developer");
		ref.setEmailId("ppp@gmail.com");
		ref.setName("fgggggg");
		
		if(us.insertReference(ref)){
			System.out.println("journal insert");
		}else{
			System.out.println("journal errror");
		}
		
		ExpertActivities exp = new ExpertActivities();
		exp.setActivityType(ExpertActivities.getActivityType(ExpertActivities.ActivityType.JOURNAL.name()));
		exp.setExportRole("fff");
		exp.setIsbnNo("123");
		exp.setLevel("middle");
		exp.setPlace("jalgaon");
		
		if(us.insertExpertActivities(exp))
		{
			System.out.println("expert");
		}
		else
		{
			System.out.println("expert errro");
		}
		
		Achievements ac = new Achievements();
		ac.setDate("2015-1-1");
		ac.setName("dsddsd");
		ac.setPlace("gfg");
		ac.setTitle("dddddd");
		
		if(us.insertAchievement(ac))
		{
			System.out.println("expert");	
		}
		else
		{
			System.out.println("expert vggv");
		}
		
		
		Projects pro = new Projects();
		pro.setDescription("vvvvvv");
		pro.setFrontEnd("java");
		pro.setGuide("rizawan");
		pro.setInputs("ffff");
		pro.setOutputs("cccc");
		pro.setTitte("hi");
		
		if(us.insertProject(pro))
		{
			System.out.println("project");
		}
		else
		{
			System.out.println("project fff");
		}*/		
	}
}
