package org.pk.resume.builder.session;

public class ProjectSessionConstant {

	public static String TITLE = "title";
	public static String GUIDE = "guide";
	public static String FRONT_END = "front_end";
	public static String BACK_END = "back_end";
	public static String INPUTS = "inputs";
	public static String OUTPUTS = "outputs";
	public static String DESCRIPTION = "description";
	
}
