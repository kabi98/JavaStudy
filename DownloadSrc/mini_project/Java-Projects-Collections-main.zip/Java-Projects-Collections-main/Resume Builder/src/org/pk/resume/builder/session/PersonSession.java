package org.pk.resume.builder.session;

public class PersonSession {
	
	public static String NAME = "name";
	public static String FATHER_NAME = "father_name";
	public static String MOTHER_NAME = "mother_name";
	public static String SURNAME = "surname";
	public static String GENDER = "gender";
	public static String DOB = "dob";
	public static String AGE = "age";
	public static String NATIONALITY = "nationality";
	public static String ADDRESS = "address";
	public static String PLACE = "place";
	public static String CONTACT_NO = "contact";
	public static String MARITAL_STATUS = "marital_status";
	public static String MAIL = "mail";
	public static String LANGUAGES = "languages"; 
	public static String CAREER_OBJECTIVES = "career_objectives";
	public static String STRENGTHS = "strengths";
	public static String HOBBIES = "hobbies";

}
