package assessment;public class Department_salary {
}
