package com.suraj.blog.config;



public class RestURIConstant {
	
}
