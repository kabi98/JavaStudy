# Crypto
This project Crypto is basically a tool that is a Text Encryption and Decryption Software that is developed using Netbeans. The aim of this project is to create a GUI(Graphical User Interface.Program that can help users to Encrypt or Decrypt messages of Images easily.


Here are some Screenshots of the Software:

![crypto_Home](https://user-images.githubusercontent.com/52830781/142254457-31508a24-19e6-4c57-a254-c6931bf5766e.JPG)

This is kind of home page for the user to select either Image Encryption or Image Decryption.


![Text Encryption   Decryption](https://user-images.githubusercontent.com/52830781/142254495-997d4d77-b47a-4507-aa88-a545acd7feb5.JPG)

Text Encryption and Decryption- The method by which information is converted into secret code that hides the information's true meaning is called Text Decryption and the reverse process of converting secret code into plain text is known as Text Decryption 


![Image Encryption And Decryption](https://user-images.githubusercontent.com/52830781/142254510-f1ac70ca-2a32-4421-80ba-8c8104555443.JPG)

Image Encryption and Decryption- Image Encryption is the process of encoding secret image with the help of some encryption algorithm in such a way that unauthorized users can't access it and the reverse process is Image Decryption.

