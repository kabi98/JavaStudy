## Email_Generator
This is basically Email Generator Application Program in Java.
<br>This program will Generate an email like this syntax: firstname.lastname@department.company.com
<br>You can select the department name, change the password, set the mailbox capacity and define an alternate email address
<br>It will Generate a random String for a password.

## How To Run this Project
1. Download zip
2. After Download Extract it.
3. Right click
4. Open folder as intellij idea project or Open folder as project eclipse
5. Than, Open Src and also open .java files and Run.
