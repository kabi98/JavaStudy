<?php

// Credential File link
define("CREDENTIALS_FILE", "data/credentials.json");

// Folder Paths
define("Gallery_Folder", "photos/");

/* Page Links */
define("Gallery_Page_Link" , "gallery.php");
define("Index_Page_Link" , "index.php");
define("Photos_Page_Link" , "photos.php");

?>