from PIL import Image
im1 = Image.open('input.jpeg')  # takes input image from present folder
im1.save('output.png')          # output image is generated the folder
