# ATM interface program using Java

A Java program can be written to simulate ATM transactions. The user must choose an option from the possibilities shown on the screen. The choices include those to withdraw money, deposit money, check your balance, and leave.
