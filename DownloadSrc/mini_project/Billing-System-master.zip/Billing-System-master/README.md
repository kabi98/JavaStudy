# Billing-System
A GUI Based Complete Store Billing System in java that generates Invoice of each sale.

      Requirments
      
This Project Requires.

Wamp Server Installed (Running).

Create database  "caddey"  and three tables "sale" , "users" and "stock".
