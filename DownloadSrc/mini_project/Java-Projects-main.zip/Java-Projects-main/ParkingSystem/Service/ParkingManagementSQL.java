package ParkingSystem.Service;



public class ParkingManagementSQL {

    public ParkingManagementSQL(){

    }



}
