# Course-Management-System
It is the object oriented, Java, console base system which have three users which is integrated with mySQL as database.

## Student - Can choose course, and enroll on the specific course. They can also see the list of instructors and modules they are studying.

## Admin - Can add new course, modules to course, cancel course, or delete the course. They can also edit course, modules, etc. and are able to print report of the specific student and show if they can pass to next level of study or not.

## Instructor - Can view modules they are on, students registered on that module and give marks to the student.
