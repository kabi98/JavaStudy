package com.baeldung.algorithms.minimax;

public class Tree {
    private Node root;

    Tree() {
    }

    Node getRoot() {
        return root;
    }

    void setRoot(Node root) {
        this.root = root;
    }
}
