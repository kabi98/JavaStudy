# 2 Player Ninja Fight Game in Java
This a small 28MB desktop game made in Java. It uses object oriented programming principles. 

Player keyboard controls are as follows:

Black ninja :- up arrow:up, down arrow:down, left arrow:left, right arrow:right, J:atk 1, K:atk 2, L:atk 3, SHIFT:jump

Blue ninja :- W:up, S:down, A:left, D:right, Z:atk 1, X:atk 2, C:atk 3, SPACE:jump

The game has a timer limit set to one minute and also shows health bars.

Hope you enjoy it...
