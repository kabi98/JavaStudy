package game1;

import java.awt.Graphics;
import game1.gfx.Assets;

public class World
{
	public void tick()
	{
		
	}
	
	public void render(Graphics g)
	{
		
		  
		 g.drawImage(Assets.bg,0,0,1920,1080, null);
		  
	}
}
