package game1;


public class launcher
{
	public static void main(String[] args)
	{
	     new front();	
		
	}
}
