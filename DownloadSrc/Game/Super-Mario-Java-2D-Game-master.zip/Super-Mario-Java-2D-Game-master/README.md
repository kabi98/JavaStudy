# My Super Mario Java 2D Game

This is a full screen 2D Java game like super mario with some basic creatures and maps.

This game is implemented using the Java programming language, using the java graphics librieries.

The used IDE is netbeans (I uploaded all project artifacts), also the game JAR file is uploaded.

This game is free to use and the code is available to anyone to learn from it without any restrictions.

Please visit my website. http://www.mohamedtalaat.net/
