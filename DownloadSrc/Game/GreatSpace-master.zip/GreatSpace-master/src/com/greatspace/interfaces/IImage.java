package com.greatspace.interfaces;

import javax.swing.ImageIcon;

/**
 *
 * @author Dayvson
 */
public interface IImage {

    ImageIcon loadImage();

}
